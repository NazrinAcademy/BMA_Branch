from django.shortcuts import render
from rest_framework import  status
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .models import Company,Branch,CurrencySetting
from .serializers import CompanySerializer,BranchSerializer,CurrencySettingSerializer,CompaniesSerializer

class CompanyViewSet(APIView):
    def post(self, request, *args, **kwargs):
        required_fields = [
            "name",
            "financial_year_start",
            "financial_year_end",
            "base_currency",
        ]
        
        missing_fields = [
            field for field in required_fields 
            if field not in request.data or not request.data.get(field)
        ]

        if missing_fields:
           return Response(
                {
                    "error": f"The following fields are missing or empty: {', '.join(missing_fields)}"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = CompanySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {
                    "message": "Company successfully created.",
                    "data": serializer.data
                },
                status=status.HTTP_201_CREATED,
            )
        else:
            return Response(
                {"error": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )
class CompanyManagementView(APIView):
    def get(self, request, company_id=None, *args, **kwargs):
        try:
            if company_id:
                company = Company.objects.get(company_id=company_id)
                serializer = CompanySerializer(company)
                return Response(
                    {"data": serializer.data},
                    status=status.HTTP_200_OK
                )
            else:
                companies = Company.objects.all()
                serializer = CompanySerializer(companies, many=True)
                return Response(
                    {"data": serializer.data},
                    status=status.HTTP_200_OK
                )
        except Company.DoesNotExist:
            return Response(
                {"error": f"Company with ID {company_id} does not exist."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def put(self, request, company_id, *args, **kwargs):
        try:
            company = Company.objects.get(company_id=company_id)
            serializer = CompanySerializer(company, data=request.data, partial=False)
            if serializer.is_valid():
                serializer.save()
                return Response(
                    {"message": "Company updated successfully", "data": serializer.data},
                    status=status.HTTP_200_OK
                )
            else:
                return Response(
                    {"errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST
                )
        except Company.DoesNotExist:
            return Response(
                {"error": f"Company with ID {company_id} does not exist."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request, company_id, *args, **kwargs):
        try:
            company = Company.objects.get(company_id=company_id)
            company.delete()
            return Response(
                {"message": "Company deleted successfully"},
                status=status.HTTP_204_NO_CONTENT
            )
        except Company.DoesNotExist:
            return Response(
                {"error": f"Company with ID {company_id} does not exist."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        


class CreateCompanyView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = CompaniesSerializer(data=request.data)
        if serializer.is_valid():
            try:
                company = serializer.save()
                return Response({
                    "message": "Company created successfully.",
                    "data": CompaniesSerializer(company).data
                }, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({
                    "error": "An unexpected error occurred.",
                    "details": str(e)
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
        detailed_errors = {
            field: error[0] for field, error in serializer.errors.items()
        }

        return Response({
            "error": "Invalid data.",
            "details": detailed_errors  
        }, status=status.HTTP_400_BAD_REQUEST)






























































class RegisterView(APIView):
    def post(self, request, *args, **kwargs):
        required_fields = ['company', 'branch_name', 'default_currency', 'timezone']
        missing_fields = [field for field in required_fields if field not in request.data]
        if missing_fields:
            return Response(
                {
                    'message': 'Missing required fields.',
                    'missing_fields': missing_fields
                },
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = BranchSerializer(data=request.data)
        
        if serializer.is_valid():
            serializer.save()
            return Response(
                {'message': 'Branch created successfully', 'branch': serializer.data},
                status=status.HTTP_201_CREATED
            )
        else:
            return Response(
                {'errors': serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )



class BranchManagementView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, branch_id=None, *args, **kwargs):
        try:
            if branch_id:
                branch = Branch.objects.get(branch_id=branch_id)
                serializer = BranchSerializer(branch)
                return Response(
                    {'branch': serializer.data},
                    status=status.HTTP_200_OK
                )
            else:
                branches = Branch.objects.all()
                serializer = BranchSerializer(branches, many=True)
                return Response(
                    {'branches': serializer.data},
                    status=status.HTTP_200_OK
                )
        except Branch.DoesNotExist:
            return Response(
                {'message': 'Branch not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'message': f'An error occurred: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def put(self, request, branch_id, *args, **kwargs):
        try:
            branch = Branch.objects.get(branch_id=branch_id)
            serializer = BranchSerializer(branch, data=request.data, partial=False)

            if serializer.is_valid():
                serializer.save()
                return Response(
                    {'message': 'Branch updated successfully', 'branch': serializer.data},
                    status=status.HTTP_200_OK
                )
            else:
                return Response(
                    {'errors': serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST
                )
        except Branch.DoesNotExist:
            return Response(
                {'message': 'Branch not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'message': f'An error occurred: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request, branch_id, *args, **kwargs):
        try:
            branch = Branch.objects.get(branch_id=branch_id)
            branch.delete()

            return Response(
                {'message': 'Branch deleted successfully'},
                status=status.HTTP_204_NO_CONTENT
            )
        except Branch.DoesNotExist:
            return Response(
                {'message': 'Branch not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'message': f'An error occurred: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class CurrencySettingPostView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            serializer = CurrencySettingSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(
                    {
                        "message": "Currency created successfully",
                        "currency": serializer.data
                    },
                    status=status.HTTP_201_CREATED
                )
            else:
                return Response(
                    {"errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST
                )
        except Exception as e:
            return Response(
                {
                    "error": f"An unexpected error occurred: {str(e)}"
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )



class CurrencySettingView(APIView):
    def get(self, request, currency_id=None, *args, **kwargs):
        try:
            if currency_id:
                currency = CurrencySetting.objects.get(currency_id=currency_id)
                serializer = CurrencySettingSerializer(currency)
                return Response(
                    {"currency": serializer.data},
                    status=status.HTTP_200_OK
                )
            else:
                currencies = CurrencySetting.objects.all()
                serializer = CurrencySettingSerializer(currencies, many=True)
                return Response(
                    {"currencies": serializer.data},
                    status=status.HTTP_200_OK
                )
        except CurrencySetting.DoesNotExist:
            return Response(
                {"error": "Currency not found."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def put(self, request, currency_id, *args, **kwargs):
        try:
            currency = CurrencySetting.objects.get(currency_id=currency_id)
            serializer = CurrencySettingSerializer(currency, data=request.data, partial=False)
            if serializer.is_valid():
                serializer.save()
                return Response(
                    {"message": "Currency updated successfully", "currency": serializer.data},
                    status=status.HTTP_200_OK
                )
            else:
                return Response(
                    {"errors": serializer.errors},
                    status=status.HTTP_400_BAD_REQUEST
                )
        except CurrencySetting.DoesNotExist:
            return Response(
                {"error": f"Currency with ID {currency_id} does not exist."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def delete(self, request, currency_id, *args, **kwargs):
        try:
            currency = CurrencySetting.objects.get(currency_id=currency_id)
            currency.delete()
            return Response(
                {"message": "Currency deleted successfully."},
                status=status.HTTP_204_NO_CONTENT
            )
        except CurrencySetting.DoesNotExist:
            return Response(
                {"error": f"Currency with ID {currency_id} does not exist."},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": f"An error occurred: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )