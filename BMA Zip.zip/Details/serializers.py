from rest_framework import serializers
from .models import Company, Branch, CurrencySetting,Companies


class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = '__all__'



class CompaniesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Companies
        fields = '__all__'

    def validate(self, attrs):
        if attrs.get('lock_period_from') and attrs.get('lock_period_to'):
            if attrs['lock_period_from'] > attrs['lock_period_to']:
                raise serializers.ValidationError("Lock period start date cannot be later than the end date.")
        return attrs

class BranchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = '__all__'

class CurrencySettingSerializer(serializers.ModelSerializer):
    class Meta:
        model = CurrencySetting
        fields = '__all__'
