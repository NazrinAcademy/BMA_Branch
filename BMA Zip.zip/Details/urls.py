from django.urls import path
# from .views import CompanyViewSet
from Details.views import CompanyViewSet,CompanyManagementView,RegisterView,BranchManagementView,CurrencySettingPostView,CurrencySettingView,CreateCompanyView
urlpatterns = [
    path('create/company/', CompanyViewSet.as_view(), name='create_company'), 
    path('companies/', CompanyManagementView.as_view(), name='get_all_companies'),
    path('companies/<uuid:company_id>/', CompanyManagementView.as_view(), name='get_company'),


    path('create/companies/', CreateCompanyView.as_view(), name='create_company'),




    path('create/branch/',  RegisterView.as_view(), name='RegisterView'),
    path('branches/', BranchManagementView.as_view(), name='get_all_branches'),
    path('branches/<uuid:branch_id>/', BranchManagementView.as_view(), name='get_or_update_delete_branch'),

    
    path('create/currency/', CurrencySettingPostView.as_view(), name='currency-create'),
    path('currencies/', CurrencySettingView.as_view(), name='currency-list'),
    path('currencies/<uuid:currency_id>/', CurrencySettingView.as_view(), name='currency-detail'),





]


