from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
import uuid


class Company(models.Model):
    company_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255, unique=True)
    mailing_name = models.CharField(max_length=255, null=True, blank=True)
    country = models.CharField(max_length=100, null=True, blank=True)
    state = models.CharField(max_length=100,null=True, blank=True)
    pincode = models.PositiveIntegerField(null=True, blank=True)
    phone_no = models.CharField(max_length=15, null=True, blank=True)
    mobile_no = models.CharField(max_length=15, null=True, blank=True, unique=True)
    fax_no = models.CharField(max_length=15, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    website = models.URLField(null=True, blank=True)
    financial_year_start = models.DateField()   
    financial_year_end = models.DateField()
    base_currency = models.CharField(max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)



    def __str__(self):
        return self.name


class Companies(models.Model):
    class BusinessType(models.TextChoices):
        MANUFACTURING = 'manufacturing', _('Manufacturing')
        TRADING = 'trading', _('Trading')
        SERVICE = 'service', _('Service')
        OTHER = 'other', _('Other')

    company_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    # financial_year_start = models.DateField()
    # financial_year_end = models.DateField()
    gst_number = models.CharField(max_length=15, unique=True, blank=True, null=True)
    pan_number = models.CharField(max_length=10, unique=True, blank=True, null=True)
    default_currency = models.CharField(max_length=10)
    multi_currency_enabled = models.BooleanField(default=False)
    multi_language_support = models.JSONField(blank=True, null=True)
    business_type = models.CharField(
        max_length=20,
        choices=BusinessType.choices,
        default=BusinessType.OTHER,
    )
    data_locking_enabled = models.BooleanField(default=False)
    lock_period_from = models.DateField(blank=True, null=True)
    lock_period_to = models.DateField(blank=True, null=True)
    default_email = models.EmailField(max_length=255, unique=True, blank=True, null=True)
    default_phone = models.CharField(max_length=15, unique=True, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
       return f"{self.gst_number or 'Company'} - {self.default_email or 'No Email'}"






# class Company(models.Model):
#     company_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     company_name = models.CharField(max_length=255, unique=True)
#     financial_year_start = models.DateField()
#     financial_year_end = models.DateField()
#     gst_number = models.CharField(max_length=50)
#     pan_number = models.CharField(max_length=50)
#     default_currency = models.CharField(max_length=10)
#     multi_currency_enabled = models.BooleanField(default=False)
#     multi_language_support = models.JSONField()
#     business_type = models.CharField(max_length=50, choices=[
#         ('manufacturing', 'Manufacturing'),
#         ('trading', 'Trading'),
#         ('service', 'Service'),
#     ])
#     data_locking_enabled = models.BooleanField(default=False)
#     lock_period_from = models.DateField(null=True, blank=True)
#     lock_period_to = models.DateField(null=True, blank=True)
#     default_email = models.EmailField()
#     default_phone = models.CharField(max_length=15)
#     created_at = models.DateTimeField(auto_now_add=True)
#     updated_at = models.DateTimeField(auto_now=True)

class Branch(models.Model):
    branch_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    branch_name = models.CharField(max_length=255)
    parent_branch = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)
    default_currency = models.CharField(max_length=10)
    timezone = models.CharField(max_length=50)

class CurrencySetting(models.Model):
    currency_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    currency_name = models.CharField(max_length=100)
    exchange_rate = models.DecimalField(max_digits=10, decimal_places=4)
    symbol = models.CharField(max_length=10)
    decimal_places = models.IntegerField()


# class AccountGroup(models.Model):
#     group_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     group_name = models.CharField(max_length=255)
#     cost_allocation_enabled = models.BooleanField(default=False)
#     cash_flow_affect = models.CharField(
#         max_length=50,
#         choices=[
#             ('operating', 'Operating'),
#             ('investing', 'Investing'),
#             ('financing', 'Financing'),
#             ('none', 'None')
#         ]
#     )

# class Ledger(models.Model):
#     ledger_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     ledger_name = models.CharField(max_length=255)
#     account_group = models.ForeignKey(AccountGroup, on_delete=models.CASCADE)
#     interest_calculation = models.BooleanField(default=False)
#     default_budget = models.DecimalField(max_digits=12, decimal_places=2)

# class LedgerDefault(models.Model):
#     ledger = models.OneToOneField(Ledger, on_delete=models.CASCADE, primary_key=True)
#     default_currency = models.CharField(max_length=10)
#     payment_terms = models.TextField()
#     tax_inclusive = models.BooleanField(default=False)
#     credit_limit = models.DecimalField(max_digits=12, decimal_places=2)

# class StockItem(models.Model):
#     item_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     item_name = models.CharField(max_length=255)
#     batch_tracking_enabled = models.BooleanField(default=False)
#     serial_number_tracking = models.BooleanField(default=False)
#     manufacturing_date = models.DateField(null=True, blank=True)
#     unit_conversion_factor = models.DecimalField(max_digits=8, decimal_places=4)

# class PricingTier(models.Model):
#     tier_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     tier_name = models.CharField(max_length=100)
#     item = models.ForeignKey(StockItem, on_delete=models.CASCADE)
#     price = models.DecimalField(max_digits=10, decimal_places=2)

# class ManufacturingUnit(models.Model):
#     unit_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     item = models.ForeignKey(StockItem, on_delete=models.CASCADE)
#     process_name = models.CharField(max_length=255)
#     output_quantity = models.DecimalField(max_digits=10, decimal_places=2)
#     input_material = models.JSONField()

# class GSTReturn(models.Model):

#     FILING_STATUS_CHOICES = [
#             ('pending', 'Pending'),
#             ('filed', 'Filed'),
#             ('rejected', 'Rejected')
#         ] 
     
#     return_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     company = models.ForeignKey(Company, on_delete=models.CASCADE)
#     return_period = models.DateField()
#     total_taxable_value = models.DecimalField(max_digits=15, decimal_places=2)
#     total_tax_paid = models.DecimalField(max_digits=15, decimal_places=2)
#     filing_status = models.CharField( max_length=50,choices=FILING_STATUS_CHOICES,)

# class Deductible(models.Model):
#     deductible_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     voucher_id = models.UUIDField()   
#     tax_deducted = models.DecimalField(max_digits=10, decimal_places=2)
#     deductible_type = models.CharField(max_length=100)

# class EmployeeBenefit(models.Model):
#     benefit_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     employee_id = models.UUIDField()  
#     benefit_name = models.CharField(max_length=255)
#     amount = models.DecimalField(max_digits=12, decimal_places=2)

# class EmployeeLoan(models.Model):
#     loan_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     employee_id = models.UUIDField()  
#     principal_amount = models.DecimalField(max_digits=15, decimal_places=2)
#     interest_rate = models.DecimalField(max_digits=5, decimal_places=2)
#     installments_due = models.IntegerField()
# class Project(models.Model):
#     project_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     project_name = models.CharField(max_length=255)
#     start_date = models.DateField()
#     end_date = models.DateField(null=True, blank=True)
#     budget = models.DecimalField(max_digits=15, decimal_places=2)

# class Asset(models.Model):
#     asset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     asset_name = models.CharField(max_length=255)
#     purchase_date = models.DateField()
#     value = models.DecimalField(max_digits=15, decimal_places=2)
#     depreciation_rate = models.DecimalField(max_digits=5, decimal_places=2)

# class CustomerPortalSetting(models.Model):
#     portal_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
#     customer_id = models.UUIDField()  
#     features_enabled = models.JSONField()
#     last_login = models.DateTimeField(null=True, blank=True)

