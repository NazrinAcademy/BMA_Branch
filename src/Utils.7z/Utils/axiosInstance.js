import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
const port = process.env.BASE_URL;
export const  axiosInstance = axios.create({
  
  baseURL:port
        //  http:// 192.168.175.125:4000
});
console.log("axiosInstance",axiosInstance);

  axiosInstance.interceptors.request.use(
  async (config) => {
    try {
      const accessToken = await AsyncStorage.getItem('accessToken');
      if (accessToken) {
        console.log("This is the token:", accessToken);
        config.headers['Authorization'] = `Bearer ${accessToken}`;
      }
      console.log('it is log for user',config);
      
      return config;
    } catch (error) {
      console.error("Error retrieving access token:", error);
      return config; // Return config even if token retrieval fails
    }
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.log('Unauthorized access - Redirecting to Login');
      // Handle redirection to login or token refresh if needed
    }
    return Promise.reject(error);
  }
);