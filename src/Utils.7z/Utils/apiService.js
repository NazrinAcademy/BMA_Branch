import axios from 'axios';
import AsyncStorage from "@react-native-async-storage/async-storage";
import { axiosInstance } from './axiosInstance';




const port = process.env.BASE_URL;
export const Loginfun = async (email, password) => {
  try {
    console.log('port',port);
    
    console.log(email,password);
    
    const response = await axios.post(`${port}admin/adminlogin`, {
      email,
      password
    });
    console.log();
    
if (response) {
console.log("response",response);
  
} else {
  console.log("no response");
  
}

    const { token } = response.data;

    if(token){
      console.log("successtoken",token);
      }

     else{
      console.log("notoken receives");
      
     } 
    
    // Store the token in AsyncStorage
    await AsyncStorage.setItem('accessToken', token);

    console.log('Token stored successfully:', token);
    
    return response.data;

  } catch (error) {
    console.error('Error logging in:', error.response?.data || error.message);
    throw error;
  }
};


//logout

export const logoutFun = async () => {
  try {
    await AsyncStorage.clear();
    console.log('AsyncStorage cleared');

    // Confirm storage is empty
    const keys = await AsyncStorage.getAllKeys();
    const values = await AsyncStorage.multiGet(keys);
    console.log('Current AsyncStorage contents:', values);

    const result = await axios.get(`${port}admin/adminlogout`);
    console.log("logoutapi", result);
    console.log("Logged out successfully");

    // Return the API response (or just a success flag)
    return result.data; // Assuming result.data contains { success: true, ... }
  } catch (error) {
    console.error('Error logging out:', error.response?.data || error.message);
    return false;
  }
};

// Function to get admin profile
export const getUserProfile = async () => {
  try {
    console.log("port",port);
    
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.get(`admin/admindetailes`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};






//Adminsales

export const addSales = async (name,email,phonenumber,password) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.post(`sales/registersales`,{name,email,phonenumber,password}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};
//sales/saleslogin

export const loginSales = async (email,password) => {
  try {
    console.log(email,password);
    
    const response = await axios.post(`${port}sales/loginsales`, {
      email,
      password
    });
    console.log();
    
if (response) {
console.log("response",response);
  
} else {
  console.log("no response");
  
}

    const { token } = response.data;

    if(token){
      console.log("successtoken",token);
      }

     else{
      console.log("notoken receives");
      
     } 
    
    // Store the token in AsyncStorage
    await AsyncStorage.setItem('accessToken', token);

    console.log('Token stored successfully:', token);
    
    return response.data;

  } catch (error) {
    console.error('Error logging in:', error.response?.data || error.message);
    throw error;
  }
};



export const getAllSales = async () => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.get(`sales/getallsalesman`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};


export const updateSales = async (id,name,email,phonenumber) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.put(`sales/updatesales/${id}`,{name,email,phonenumber}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};
///deletesales/:id
export const deleteSales = async (id) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.delete(`sales/deletesales/${id}`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};


//Adminproduction 
export const addProduction = async (name,email,phonenumber,password) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.post(`production/registerproduction`,{name,email,phonenumber,password}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};

export const getAllProduction = async () => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.get(`production/getallproduction`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};


export const updateProduction = async (id,name,email,phonenumber) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.put(`production/updateproduction/${id}`,{name,email,phonenumber}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};

export const deleteProduction = async (id) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.delete(`production/deleteproduction/${id}`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};

//AdminQc

export const addQc = async (name,email,phonenumber,password) => {
  try {
    console.log("qc api");
    
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.post(`qc/registerqc`,{name,email,phonenumber,password}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdataqc',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};

//Admingetallsales
export const getAllQc = async () => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.get(`qc/getallqcdetailes`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdataqc',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};


export const updateQc = async (id,name,email,phonenumber) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.put(`qc/updateqc/${id}`,{name,email,phonenumber}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};
///deletesales/:id
export const deleteQc = async (id) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.delete(`qc/deleteqc/${id}`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};


//Adminac1

export const addAc1 = async (name,email,phonenumber,password) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.post(`ac1/registerac1`,{name,email,phonenumber,password}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};


//adminac2


export const addAc2 = async (name,email,phonenumber,password) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.post(`ac2/registerac2`,{name,email,phonenumber,password}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};

///colorshade
//productType,colorshades
export const addColorshade = async (producttype, colorshades) => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken');

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    
    console.log("accessToken get successfully", accessToken);

    const response = await axiosInstance.post(`colorshade/createcolorshade`,
      { producttype, colorshades },
      {
        headers: {
          Authorization: `${accessToken}`,
          
        },
      }
    );

    if (response) {
      return response.data;
    } else {
      console.log("Error fetching user data");
    }
  } catch (error) {
    console.error('Error sending colorshade data:', error.response?.data || error.message);
    throw error;
  }
};

///colorshade/getcolorshade
export const getColorshade = async () => {
  try {
    const accessToken = await AsyncStorage.getItem('accessToken');

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }

    console.log("Access token retrieved:", accessToken);

    const response = await axiosInstance.get(`colorshade/getcolorshade`, {
      headers: {
        Authorization: `${accessToken}`,
      },
    });

    if (response.data) {
      console.log("Color shade data received:", response.data);
      return response.data; // ✅ Correctly return the response
    } else {
      throw new Error("No data received");
    }
  } catch (error) {
    console.error("Error fetching color shades:", error.response?.data || error.message);
    throw error;
  }
};


//colorshade by producttype

///colorshade/getcolorshadebyname?producttype=Membrane Doors

export const getColorshadeByname = async (producttype) => {
  try {
    console.log('producttype in api ',producttype);
    
    const accessToken = await AsyncStorage.getItem('accessToken');

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }

    console.log("Access token retrieved:", accessToken);

    const response = await axiosInstance.get(`colorshade/getcolorshadebyname?producttype=${producttype}`, {
      headers: {
        Authorization: `${accessToken}`,
      },
    });

    if (response.data) {
      console.log("Color shade data received:", response.data);
      return response.data; 
    } else {
      throw new Error("No data received");
    }
  } catch (error) {
    console.error("Error fetching color shades:", error.response?.data || error.message);
    throw error;
  }
};

export const addProduct = async (totalprocessingtime,pr1,pr2,pr3,pr4,colorshadedetailes,height,width,modelno,thickness) => {
  
  try {
   console.log("from api",totalprocessingtime,pr1,pr2,pr3,pr4,colorshadedetailes,height,width,modelno,thickness);
   
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.post(`product/createproduct`,{totalprocessingtime,pr1,
      pr2,
      pr3,
      pr4,colorshadedetailes,height,width,modelno,thickness}, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};



//sales

export const SalesLoginfun = async (email, password) => {
  try {
    console.log(email,password);
    
    const response = await axios.post(`${port}sales/loginsales`, {
      email,
      password
    });
    console.log();
    
if (response) {
console.log("response",response);
  
} else {
  console.log("no response");
  
}

    const { token } = response.data;

    if(token){
      console.log("successtoken",token);
      }

     else{
      console.log("notoken receives");
      
     } 
    
    // Store the token in AsyncStorage
    await AsyncStorage.setItem('accessToken', token);

    console.log('Token stored successfully:', token);
    
    return response.data;

  } catch (error) {
    console.error('Error logging in:', error.response?.data || error.message);
    throw error;
  }
};


export const getSalesProfile = async () => {
  try {
    console.log("process.env.BASE_URL",port);
    
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.get(`sales/salesdetailes`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};



//production

export const ProductionLoginfun = async (email, password) => {
  try {
    console.log(email,password);
    
    const response = await axios.post(`${port}production/loginproduction`, {
      email,
      password
    });
    console.log();
    
if (response) {
console.log("response",response);
  
} else {
  console.log("no response");
  
}

    const { token } = response.data;

    if(token){
      console.log("successtoken",token);
      }

     else{
      console.log("notoken receives");
      
     } 
    
    // Store the token in AsyncStorage
    await AsyncStorage.setItem('accessToken', token);

    console.log('Token stored successfully:', token);
    
    return response.data;

  } catch (error) {
    console.error('Error logging in:', error.response?.data || error.message);
    throw error;
  }
};


export const getproductionProfile = async () => {
  try {
    console.log("process.env.BASE_URL",process.env.BASE_URL);
    
    const accessToken = await AsyncStorage.getItem('accessToken'); // Retrieve token directly

    if (!accessToken) {
      throw new Error('Authorization token is missing');
    }
    else{{
      console.log("accessToken get successfullly",accessToken);
      
    }}

    const response = await axiosInstance.get(`${port}production/productiondetailes`, {
      headers: {
        Authorization: `${accessToken}`, // Use the retrieved token
      },
    });
   if (response) {
    console.log('userdata',response.data);
    

    return response.data; // Return user profile data if needed
   } else {
    console.log("error to user data");
    
   }
  } catch (error) {
    console.error('Error fetching user profile:', error.response?.data || error.message);
    throw error;
  }
};

//qc

