import React from "react";


const LoadingBox=()=>{

  return(
    <>
    </>
  )
}